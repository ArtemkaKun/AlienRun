---Spine model API documentation
---Spine model API documentation
---@class spine
spine = {}



return spine